﻿//===============================================================================
// Copyright © 2009 CM Streaming Technologies.
// All rights reserved.
// http://www.cmstream.net
//===============================================================================

using System.Windows;

namespace Mp4Explorer
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ConvertVideoToMp4Window : Window
    {
        public ConvertVideoToMp4Window()
        {
            InitializeComponent();
        }

        private void buttonConvert_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
