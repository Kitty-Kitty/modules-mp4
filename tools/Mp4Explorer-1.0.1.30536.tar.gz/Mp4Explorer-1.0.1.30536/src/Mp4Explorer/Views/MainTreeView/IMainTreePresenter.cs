﻿//===============================================================================
// Copyright © 2009 CM Streaming Technologies.
// All rights reserved.
// http://www.cmstream.net
//===============================================================================

namespace Mp4Explorer
{
    public interface IMainTreePresenter
    {
        IMainTreeView View { get; set; }
    }
}
