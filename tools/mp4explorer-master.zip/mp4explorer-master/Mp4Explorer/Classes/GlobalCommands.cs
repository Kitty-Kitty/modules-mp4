﻿//===============================================================================
// Copyright © 2009 CM Streaming Technologies.
// All rights reserved.
// http://www.cmstream.net
//===============================================================================

using Microsoft.Practices.Composite.Presentation.Commands;

namespace Mp4Explorer
{
    /// <summary>
    /// 
    /// </summary>
    public static class GlobalCommands
    {
        /// <summary>
        /// 
        /// </summary>
        public static CompositeCommand OpenCommand = new CompositeCommand();
    }
}
