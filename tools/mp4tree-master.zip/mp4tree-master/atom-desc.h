#pragma once

#include <stdint.h>

const char *get_box_desc(const uint8_t *type);

